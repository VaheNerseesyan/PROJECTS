from django.db import models


class About(models.Model):
    title = models.CharField(max_length=20)
    bio = models.ImageField(upload_to='media/bio')

    def __str__(self):
        return self.title
