from django.contrib import admin

from homepage.models import About

admin.site.register(About)
