from django.shortcuts import render
from doctors.models import Doctor
from homepage.models import About
from patients.models import Patient
from solutions.models import Solution


def homepage(request):
    home = About.objects.all()
    solutions = Solution.objects.all()
    doctors = Doctor.objects.all()
    patient = Patient.objects.all()

    context = {
        'home': home,
        'solutions': solutions,
        'doctors': doctors,
        'patient': patient
    }
    return render(request, "home.html", context)
