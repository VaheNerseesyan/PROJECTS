from django.contrib import admin

from solutions.models import Solution

admin.site.register(Solution)