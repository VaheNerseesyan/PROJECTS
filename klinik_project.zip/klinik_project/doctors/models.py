from django.db import models


class Doctor(models.Model):
    avatar = models.ImageField(upload_to='media/avatars')
    doctor_name = models.CharField(max_length=25)
    department = models.CharField(max_length=25)
    slug = models.SlugField(unique=True)

    def __str__(self):
        return self.doctor_name
