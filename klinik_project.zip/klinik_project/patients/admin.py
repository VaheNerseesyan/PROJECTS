from django.contrib import admin

from patients.models import Patient

admin.site.register(Patient)
