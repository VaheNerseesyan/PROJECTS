from django.db import models


class Patient(models.Model):
    icon = models.ImageField(upload_to='media/icon')
    description = models.TextField(100)
    patient_name = models.CharField(max_length=25)
    profession = models.CharField(max_length=25)

    def __str__(self):
        return self.description
